# Portfólio profissional — Pedro Medeiros

Portfólio desenvolvido em HTML5 e CSS3 para apresentar a formação, conhecimentos, interesses e contatos profissionais de Pedro Medeiros.

## Sobre o projeto

O projeto segue a proposta de organização de um portfólio profissional com:

- identidade profissional;
- apresentação pessoal;
- formação;
- conhecimentos técnicos;
- competências comportamentais;
- áreas de interesse;
- espaço para projetos reais;
- currículo;
- links profissionais;
- contato;
- layout responsivo;
- acessibilidade básica.

## Tecnologias utilizadas

- HTML5
- CSS3
- GitHub Pages

## Estrutura

```text
portfolio-pedro/
├── index.html
├── style.css
├── README.md
└── assets/
    └── curriculo.pdf
```

## Projetos

Os cartões de projetos presentes no HTML são espaços de organização. Devem ser substituídos por projetos reais desenvolvidos pelo estudante, com descrição, tecnologias, participação, aprendizados e links.

## Currículo

Coloque o currículo revisado em:

`assets/curriculo.pdf`

Evite publicar CPF, RG, endereço completo, senhas, tokens, chaves de API ou outros dados confidenciais.

## Publicação no GitHub Pages

1. Crie um repositório público para o portfólio.
2. Envie `index.html`, `style.css`, `README.md` e a pasta `assets`.
3. Confirme que `index.html` está na raiz.
4. Acesse **Settings > Pages**.
5. Em **Build and deployment**, selecione **Deploy from a branch**.
6. Selecione a branch `main` e a pasta `/(root)`.
7. Salve e aguarde a publicação.
8. Teste o endereço publicado em outro dispositivo ou janela anônima.

## Autoria

Pedro Medeiros.

## Licença

Nenhuma licença específica foi escolhida neste arquivo. Defina uma licença somente se isso fizer parte da decisão do projeto.
